//
//  ViewController.swift
//  iOS3
//
//  Created by cstech on 3/26/18.
//  Copyright © 2018 VCU. All rights reserved.
//

import UIKit

//Bug: Move with one button to other segues' ViewControllers

class ViewController: UIViewController { //MAIN VIEW (MENU)
    
    //1- IBOutlets
    @IBOutlet weak var playBTN: UIButton!

    //2- SENT VARS
    var chosenDifficulty = 0 //tag of Button [3, 4, 5]
    var chosenGame = 0 //tags of game buttons [10, 20, 30] by order
    
    //RECEIVED VARS:
    var LATEST_HIGHSCORE: Int?
    
    //VARS
    private var FiveHighScores = [[Int]]() //[ChosenGameTag][Score]
    
    //3- Actions
    @IBAction func unwindToMainVC(segue: UIStoryboardSegue)
    {
        playBTN.isUserInteractionEnabled = false
        chosenGame = 0 ; chosenDifficulty = 0;
        print ("I unwind")
        if segue.identifier == "unwindToMainSegue"
        {
            if let source = segue.source as? AllGames
            {
                LATEST_HIGHSCORE = source.globalScore
                
                FiveHighScores.append([source.chosengame!, LATEST_HIGHSCORE!])
                FiveHighScores.sort(by: { $1[0] < $0[0] }) //sort
                if FiveHighScores.count == 6 //and remove smallest score
                {
                    FiveHighScores.remove(at: FiveHighScores.count - 1)
                }
            }
        }
    }
    
    @IBAction func showHighScorePopUpAction(_ sender: UIBarButtonItem)
    {
        let alertHS = UIAlertController(title: "High Score", message: listFiveHighScores(), preferredStyle: .alert)
        alertHS.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: nil))
        self.present(alertHS, animated: true, completion: nil)
    }
    
    //1// Game
    @IBAction func memBTN_ACTION(_ sender: UIButton) {
        chosenGame = sender.tag
        enablePlay()
        sender.isHighlighted = true;
    }
    
    @IBAction func sortingBTN_ACTION(_ sender: UIButton) {
        chosenGame = sender.tag
        enablePlay()
    }
    @IBAction func ballonsBTN_ACTION(_ sender: UIButton) {
        chosenGame = sender.tag
        enablePlay()
    }
    
    //2// Game difficulty: tag(button) = level of difficulty [3, 4, 5]
    @IBAction func easyBTN_ACTION(_ sender: UIButton)
    {
        chosenDifficulty = sender.tag
        enablePlay()
    }
    @IBAction func medBTN_ACTION(_ sender: UIButton)
    {
        chosenDifficulty = sender.tag
        enablePlay()
    }
    @IBAction func hardBTN_ACTION(_ sender: UIButton)
    {
        chosenDifficulty = sender.tag
        enablePlay()
    }
    
    private func enablePlay()
    {
        if(chosenDifficulty != 0 && chosenGame != 0)
        {
            playBTN.isUserInteractionEnabled = true
        }
        else if(chosenDifficulty == 0 && chosenGame == 0)
        {
            playBTN.isUserInteractionEnabled = false
        }
    }
    @IBAction func playStart(_ sender: UIButton) {
        if(chosenGame != 0 && chosenDifficulty != 0)
        {
            self.shouldPerformSegue(withIdentifier: "AllGamesSegue", sender: self) //perform segue
        }
        else
        {
            let alert = UIAlertController(title: "Error", message: "Choose a game.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alert, animated: true)
        }
    }
    
    //4- FUNCTIONS
    override func viewDidLoad() {
        super.viewDidLoad()
        playBTN.isUserInteractionEnabled = false
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) { //prepare first
        if segue.identifier == "AllGamesSegue"
        {
            if let dest = segue.destination as? AllGames
            {
                dest.gridX = chosenDifficulty
                dest.chosengame = chosenGame
            }
        }
    }
    private func getGameName(gameTag: Int) -> String
    {
        var gamename = String()
        switch chosenGame {
        case 10:
            gamename = "Memory Game"
        case 20:
            gamename = "Sorting Game"
        case 30:
           gamename = "Ballons Game"
        default:
            gamename = ""
        }
        return gamename
    }
    private func listFiveHighScores() -> String
    {
        var list = ""
        for i in stride(from: 0, to: FiveHighScores.count, by: 1)
        {
            list += "\(i+1) - \(getGameName(gameTag: FiveHighScores[i][0]))  : \(FiveHighScores[i][1])\n"
        }
        return list;
    }
    
    
    //unwind: https://medium.com/@mimicatcodes/create-unwind-segues-in-swift-3-8793f7d23c6f
}
