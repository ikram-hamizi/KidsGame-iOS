//
//  AllGames.swift
//  iOS3 - Kids Game
//
//  Created by Ikram Hamizi on 3/28/18.
//  Copyright © 2018 VCU. All rights reserved.
//

import UIKit
import AVFoundation

/* Bugs:
~~Game 3:
- Tap Gesture Not detected during animation (balloons)
*/


class AllGames: UIViewController, UIGestureRecognizerDelegate {
    @IBOutlet var panGR: UIPanGestureRecognizer!
   
    //1- Received vars from segue: MEMORY
    var chosengame: Int?
    var gridX: Int? //difficutly of game
    
    // - Vars sent to segue: MainVC (ViewController)
    var globalScore = 0
    
    //2- Local vars
    private var player: AVAudioPlayer!
    private var btnARR: [UIButton]!
    private var BGImageView: UIImageView!
    
    private let W = UIScreen.main.bounds.width
    private let H = UIScreen.main.bounds.height
    
    private var randARR: [UInt32]!
    private var imageAnswers: [UIImageView]!
    private var imgAnsTagTuples: [[Int]]!
    
    private var scoreTimer = Timer()
    private var globalTimer = Timer()
    
    private var showCard1TIME = Timer()
    private var showCard2TIME = Timer()
    
    private var globalTimeL: UILabel!
    
    var globalSeconds = 0
    private  var timeElapsed = 0
    private var count = 0;
    private var rand: UInt32!
    
    private var globalScoreL: UILabel!
    private var globalScoreIMG: UIImageView!
    
    private var tagAns = [Int]()
    private var clickedCard1 = UIButton()
    private var clickedCard2 = UIButton()
    private var CORRECT = false
    
    //I- GLOBAL FUNCTION: VIEW DID LOAD
    override func viewDidLoad()
    {
        startGame()
    }
    
    private func startGame()
    {
        print("VIEW DID LOAD")
        reset()
        globalSeconds = 0
        switch chosengame!
        {
        case 10: initMemoryGame(); self.title = "Memory Game"
        case 20: initSortingGame(); self.title = "Sorting Game"
        case 30: initBallonsGame(); self.title = "Ballons Game"
        default:
            print("Default")
        }
        globalTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(decrementGlobalTimer), userInfo: nil, repeats: true)
    }
    //II- Initializing Variables and Views
    //------------------------------------- INITIALIZING GAMES START ------------------------------------
    
    // [1]- INIT - Game 1: Memory
    private func initMemoryGame()
    {
        btnARR = [UIButton]()
        randARR = [UInt32]()
        imageAnswers = [UIImageView]()
        imgAnsTagTuples = [[Int]]()
        
        switch gridX!
        {
        case 3:
            globalSeconds = 120
            break;
        case 4:
            globalSeconds = 105
            break;
        case 5:
            globalSeconds = 90
            break;
        default: globalSeconds = 120
        }
        
        var count = 0
        
        let bgImage = UIImage(named: "background")
        BGImageView = UIImageView(image: bgImage)
        BGImageView.contentMode = .scaleToFill
        BGImageView.isUserInteractionEnabled = true
        self.view.addSubview(BGImageView)
        
        addScoreAndTimeToGame()
        
        for i in stride(from: 0, to: gridX!, by: 1)
        {
            for j in stride(from: 0, to: 4, by: 1)
            {
                //1- Answer Images
                repeat {
                    rand = arc4random_uniform(UInt32(4*gridX!/2+1))
                } while (timesImageWasPicked(rand) == 2 || rand == 0)
                
                if timesImageWasPicked(rand) == 1
                {
                    let existingImgIndex = indexRand(rand)
                    //imgAnsTagTuples.append([imageAnswers[existingImgIndex].tag, count+1]) //count+1 -> tags start from 1...max
                    imgAnsTagTuples.append([imageAnswers[existingImgIndex].tag, Int(rand)]) //count+1 -> tags start from 1...max
                }
                
                randARR.append(rand)
                //print ("rand: \(rand)")
                
                let answer_j = UIImageView(image: UIImage(named: "\(Int(rand))"))
                var X = 168 * i + (1024-(gridX!*152+gridX!))/2
                var Y = 100 + j * 156
                answer_j.frame = CGRect(x: X ,y: Y, width: 100, height: 105)
                //answer_j.tag = count+1
                answer_j.tag = Int(rand)
                
                imageAnswers.append(answer_j)
                self.BGImageView.addSubview(answer_j)
                
                //getTupleTag1(tag1: tagAns[0]) == tagAns[1]
                
                //2- Cards
                let btn_j = UIButton.init(type: UIButtonType.custom) as UIButton
                let img = UIImage(named: "card")
                X = 165 * i + (1024-(gridX!*165+gridX!))/2
                Y = 100 + j * 156
                btn_j.frame = CGRect(x: X ,y: Y, width: 165, height: 155)
                btn_j.setImage(img, for: .normal)
                btn_j.addTarget(self, action: #selector(tapped), for: .touchUpInside)
                //btn_j.tag = count+1
                btn_j.tag = Int(rand)
                
                btnARR.append(btn_j)
                self.BGImageView.addSubview(btnARR[btnARR.count - 1])

                count += 1
            }
        }
    }

    // [2]- INIT - Game 2: Sorting
    private var numSortable = 0
    private var panGRARR = [UIPanGestureRecognizer]()
    
    private func initSortingGame()
    {
        let bgImage = UIImage(named: "air-land-water")
        BGImageView = UIImageView(image: bgImage)
        BGImageView.contentMode = .scaleAspectFill
        BGImageView.frame = CGRect(x: 0, y: 0, width: W, height: H)
        globalSeconds = 0
        
        self.view.addSubview(BGImageView)
        addScoreAndTimeToGame()
        
        var X = 0
        
        switch gridX!
        {
        case 3:
            numSortable = 8
            globalSeconds = 60
            break;
        case 4:
            numSortable = 10
            globalSeconds = 45
            break;
        case 5:
            numSortable = 12
            globalSeconds = 30
            break;
        default: numSortable = 8
        }
        
        for i in stride(from: 0, to: numSortable, by: 1)
        {
            repeat {
                rand = arc4random_uniform(UInt32(numSortable+1)) + 10
            } while (timesImageWasPicked(rand) == 1 || rand == 10)
            
            randARR.append(rand)
            
            let sortable = UIImageView(image: UIImage(named: "\(Int(rand))"))
            //Image names: [11-15]: E + [16-20]: S + [21-25]: W - Each 5 pictures
            
            X = 80 * i + 22
            sortable.frame = CGRect(x: X ,y: 118, width: 75, height: 75)
            sortable.tag = Int(rand)
            sortable.isUserInteractionEnabled = true
            
            imageAnswers.append(sortable)
            panGRARR.append(UIPanGestureRecognizer(target: self, action: #selector(panned)))
            panGRARR[count].delegate = self
            sortable.addGestureRecognizer(panGRARR[count])
            self.view.addSubview(sortable)
            
            count += 1
        }
    }
    
    // [3]- INIT - Game 3: ballons
    private func initBallonsGame()
    {
        let bgImage = UIImage(named: "sky-background")
        BGImageView = UIImageView(image: bgImage)
        BGImageView.contentMode = .scaleAspectFill
        BGImageView.frame = CGRect(x: 0, y: 0, width: W, height: H)
        self.view.addSubview(BGImageView)
        BGImageView.isUserInteractionEnabled = false
        self.view.isUserInteractionEnabled = false
        
        addScoreAndTimeToGame()
        
        maxScoreBallon = 0
        
        switch gridX!
        {
        case 3:
            maxScoreBallon = 9
            globalSeconds = 60
            break;
        case 4:
            maxScoreBallon = 7
            globalSeconds = 45
            break;
        case 5:
            maxScoreBallon = 5
            globalSeconds = 30
            break;
        default: globalSeconds = 60
        }
        
         ballonAppearsTimer = Timer.scheduledTimer(timeInterval: 3, target: self, selector: #selector(ballonAppears), userInfo: nil, repeats: true)
    }
    
    //--------------------------------------- INITIALIZE GAMES END ---------------------------------------
    
    /////////*******************************GAME 1: MEMORY FNS *******************************/////////
    //Ikram - 2:19 am
    private func getTupleTag1(tag1: Int) -> Int
    {
        for i in stride(from: 0, to: imgAnsTagTuples.count, by: 1)
        {
            if imgAnsTagTuples[i][0] == tag1
            {
                return imgAnsTagTuples[i][1]
            }
            if imgAnsTagTuples[i][0] == tag1
            {
                return imgAnsTagTuples[i][1]
            }
        }
        return -1
    }
    private var showCardsTIME = Timer()
    
    private func enableInteractionAllQuestionCards(enabled: Bool)
    {
        for i in stride(from: 0, to: btnARR.count, by: 1)
        {
            btnARR[i].isUserInteractionEnabled = enabled
        }
    }
    @objc private func tapped(_ sender: UIButton!)
    {
        timeElapsed = 0
        
        tagAns.append(sender.tag)
        count = 0;
        CORRECT = false
        
        if tagAns.count == 1
        {
            print("Tag \(tagAns.count): \(sender.tag)")
            
            clickedCard1 = sender
            clickedCard1.isHidden = true
            clickedCard2 = UIButton() //reset
            
            scoreTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(startScoreTimer), userInfo: nil, repeats: true) //Start Timing for score
        }
        else if tagAns.count == 2 //Two cards chosen -> match old with new
        {
            clickedCard2 = sender
            clickedCard2.isHidden = true
            enableInteractionAllQuestionCards(enabled: false)
            print ("SECOND button tapped... ")
            print("Tag \(tagAns.count): \(sender.tag)")
            
            showCardsTIME = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(showCT), userInfo: nil, repeats: true) //Show cards for 1 second
            Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(hideCT), userInfo: nil, repeats: false)
            
            if getTupleTag1(tag1: tagAns[0]) == tagAns[1]
            {
                CORRECT = true
                print ("-----> CORRECT GOOD JOB! ")
                clickedCard1.isHidden = true
                clickedCard2.isHidden = true
                
                showCardsTIME.invalidate()
                
                if (timeElapsed <= 3)
                {
                    globalScore += 5
                }
                else if (timeElapsed <= 7)
                {
                    globalScore += 4
                }
                else if (timeElapsed > 7)
                {
                    globalScore += 3
                }
                globalScoreL.text = "\(globalScore)"
                
                CORRECTLY_ANSWERED_COUNT += 1
                if (CORRECTLY_ANSWERED_COUNT == gridX!*4/2)
                {
                    gameEndAlertAndTimeInvalidate()
                }
            }
            else
            {
                print("You chose the wrong card.")
                CORRECT = false
                scoreTimer.invalidate()
            }
            tagAns = [Int]() //Reset
        }
    }
    
    @objc private func showCT()
    {
        count += 1
    }
    @objc private func hideCT()
    {
        enableInteractionAllQuestionCards(enabled: true)
        if !CORRECT
        {
            print ("HIDE")
            showCardsTIME.invalidate()
            clickedCard1.isHidden = false
            clickedCard2.isHidden = false
        }
    }
    /////////#############################GAME 1: MEMORY END END END #############################/////////
    
    /////////*******************************GAME 2: Sorting START ********************************/////////
    private var originalLocation = CGRect()
    
    private var locationOfBeganTap: CGPoint!
    private var locationOfEndTap: CGPoint!
    
    private var CORRECTLY_ANSWERED_COUNT = 0
    
    @objc private func panned(_ sender: UIPanGestureRecognizer){
        
        let point = sender.translation(in: self.view)
        let currentSortableImage = sender.view!
        if sender.state == UIGestureRecognizerState.began
        {
            scoreTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(startScoreTimer), userInfo: nil, repeats: true) //Start Timing for score
            locationOfBeganTap = sender.location(in: view)
            originalLocation = currentSortableImage.frame
        }
        if sender.state == UIGestureRecognizerState.changed
        {
            //currentSortableImage.transform = CGAffineTransform(translationX: point.x, y: point.y) //Keeps fidgeting
            currentSortableImage.center = CGPoint(x: currentSortableImage.center.x + point.x, y: currentSortableImage.center.y + point.y)
            sender.setTranslation(CGPoint.zero, in: self.view)
        }
        else if sender.state == UIGestureRecognizerState.ended
        {
            
            locationOfEndTap = sender.location(in: self.view)
            if(!isInRightLocation(sortableImage: currentSortableImage as! UIImageView))
            {
                currentSortableImage.frame = originalLocation
            }
            else
            {
                currentSortableImage.isUserInteractionEnabled = false
                
                if (timeElapsed <= 2)
                {
                    globalScore += 5
                }
                else if (timeElapsed <= 4)
                {
                    globalScore += 4
                }
                else if (timeElapsed > 4)
                {
                    globalScore += 3
                }
                globalScoreL.text = "\(globalScore)"
                
                CORRECTLY_ANSWERED_COUNT += 1
                playDropObject()
                if (CORRECTLY_ANSWERED_COUNT == numSortable)
                {
                    gameEndAlertAndTimeInvalidate()
                }
            }
        }
    }
    
    private var SKY = [CGPoint(x: 0, y: 0),CGPoint(x: 1024, y: 439)] //[start, end]
    private var WATER_UP = [CGPoint(x: 0, y: 440),CGPoint(x: 755.0, y: 608)]
    private var WATER_DOWN = [CGPoint(x: 0, y: 609.0),CGPoint(x: 471.5, y: 768)]
    
    private func isInRightLocation(sortableImage: UIImageView) -> Bool //tag = image_name_number
    {
        switch sortableImage.tag {
        case 11 ... 15: //Eearth
            if !(WATER_UP[0].x ... WATER_UP[1].x ~= sortableImage.frame.origin.x && WATER_UP[0].y ... WATER_UP[1].y ~= sortableImage.frame.origin.y) && !(WATER_DOWN[0].x ... WATER_DOWN[1].x ~= sortableImage.frame.origin.x && WATER_UP[0].y ... WATER_UP[1].y ~= sortableImage.frame.origin.y) && !(SKY[0].x ... SKY[1].x ~= sortableImage.frame.origin.x && SKY[0].y ... SKY[1].y ~= sortableImage.frame.origin.y)
            {
                //print("Earth")
                return true
            }
        case 16 ... 20: //Sky
            if(SKY[0].x ... SKY[1].x ~= sortableImage.frame.origin.x && SKY[0].y ... SKY[1].y ~= sortableImage.frame.origin.y)
            {
                //print("Sky")
                return true
            }
        case 21 ... 25: //Water
            if(WATER_UP[0].x ... WATER_UP[1].x ~= sortableImage.frame.origin.x && WATER_UP[0].y ... WATER_UP[1].y ~= sortableImage.frame.origin.y) || (WATER_DOWN[0].x ... WATER_DOWN[1].x ~= sortableImage.frame.origin.x && WATER_UP[0].y ... WATER_UP[1].y ~= sortableImage.frame.origin.y)
            {
                //print("Water")
                return true
            }
        default:
            //print("failure")
            return false
        }
        return false
    }
    
    /////////#############################GAME 2: Sorting END END END #############################/////////
    
    /////////*******************************GAME 3: BALLOONS FNS *******************************/////////
    private var popGR = [UITapGestureRecognizer]()
    private var ballonSpeed = 7.0
    private var ballonAppearsTimer = Timer()
    private var maxScoreBallon = 0
    
    @objc private func ballonAppears()
    {
        var randX = UInt32(0)
        var ballonIV: UIImageView!
        //var btn_j: UIButton!
        
        //Create Ballons
        rand = arc4random_uniform(UInt32(11))
        randScoreBallon = arc4random_uniform(UInt32(maxScoreBallon+1))
        let scoreBallonLabel = UILabel()
        scoreBallonLabel.text = "\(randScoreBallon)"
        //var img: UIImage!
        //btn_j = UIButton.init(type: UIButtonType.custom) as UIButton
        
        if(randScoreBallon == 0)
        {
            ballonIV = UIImageView(image: UIImage(named: "skull"))
          
            //img = UIImage(named: "skull)")
        }
        else
        {
            ballonIV = UIImageView(image: UIImage(named: "color\(Int(rand))"))
            //img = UIImage(named: "color\(Int(rand))")
        }
        
        repeat {
            randX = arc4random_uniform(UInt32(900))
        } while (randX < 40)
        
        if(ballonSpeed > 1.5)
        {
            ballonSpeed -= 0.001
        }
//        btn_j.frame = CGRect(x: Int(randX) ,y: 770, width: 65, height: 75)
//        btn_j.setImage(img, for: .normal)
//        btn_j.addTarget(self, action: #selector(popped), for: .touchUpInside)
//        btn_j.tag = Int(rand)
//        btn_j.isUserInteractionEnabled = true
//        btnARR.append(btn_j)
//        self.BGImageView.addSubview(btnARR[btnARR.count - 1])
        
        ballonIV.frame = CGRect(x: Int(randX) ,y: 770, width: 65, height: 75) //initial
        ballonIV.tag = Int(randScoreBallon)
        ballonIV.isUserInteractionEnabled = true
        scoreBallonLabel.frame = CGRect(x: ballonIV.frame.origin.x ,y: ballonIV.frame.origin.y, width: 60, height: 60)

        popGR.append(UITapGestureRecognizer(target: self, action: #selector(popped)))
        popGR[count].delegate = self
        popGR[count].numberOfTapsRequired = 1
        popGR[count].numberOfTouchesRequired = 1
        ballonIV.addGestureRecognizer(popGR[count])
        
        //ballonIV.addSubview(scoreBallonLabel)
        self.view.addSubview(ballonIV)
        count += 1

//        UIView.animateKeyframes(withDuration: TimeInterval(ballonSpeed), delay: 2, options: [UIViewKeyframeAnimationOptions.allowUserInteraction], animations: {
//            for i in stride(from: 0, to: 800, by: 1)
//            {
//                UIView.addKeyframe(withRelativeStartTime: Double(i)*self.ballonSpeed/800, relativeDuration: self.ballonSpeed/800, animations: {
//                    ballonIV.frame.origin.y -= 1 })
//            }
//        }, completion: nil)
        
        UIView.animate(withDuration: TimeInterval(ballonSpeed), delay: 2, options: [.allowUserInteraction, .allowUserInteraction, .allowAnimatedContent, .curveEaseIn], animations: {
                ballonIV.frame.origin.y -= 800
            }, completion: nil)
        
//                UIView.animate(withDuration: TimeInterval(ballonSpeed), delay: 2, options: [.allowUserInteraction, .allowAnimatedContent, .curveEaseIn], animations: {
//                        btn_j.frame.origin.y -= 800
//                    }, completion: nil)

    }
    
    @objc private func popped(_ sender: UIImageView!)
    {
//        globalScore += (sender.view?.tag)!
//        print("Pooped \((sender.view?.tag)!)")
//        sender.view?.isHidden = true
        
        globalScore += (sender.tag)
        print("Pooped \((sender.tag))")
        sender.isHidden = true
    }
    private var randScoreBallon = UInt32(0)
    /////////#############################GAME 3: BALLOONS END END END #############################/////////
    
    
    //4- Global FUNCTIONS
    private func reset()
    {
        randARR = [UInt32]()
        count = 0
        imageAnswers = [UIImageView]()
        globalScore = 0
        timeElapsed = 0
        popGR = [UITapGestureRecognizer]()
        panGR = UIPanGestureRecognizer()
        panGRARR = [UIPanGestureRecognizer]()
        btnARR = [UIButton]()
    }
    
    //Function counts how many times the card images was picked (number allowed: 2 times)
    private func timesImageWasPicked(_ rand: UInt32) -> Int
    {
        var count = 0
        for i in stride(from: 0, to: randARR.count, by: 1)
        {
            if randARR[i] == rand
            {
                count += 1
            }
        }
        return count
    }
    
    private func gameEndAlertAndTimeInvalidate()
    {
        if(globalScore > 0)
        {
            playCheer()
        }
        globalTimer.invalidate()
        let alert = UIAlertController(title: "Game Over", message: "Your score is: \(globalScore)! Play again?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Play again", style: .default, handler: { (action) in
            self.startGame()
        }))
        alert.addAction(UIAlertAction(title: "Back", style: .destructive, handler: {(action) in
            print("unwind")
            self.goBackToMainVC(action)
        })) //unwind
        self.present(alert, animated: true, completion: nil)
    }
    
    private func goBackToMainVC (_ sender: Any)
    {
        performSegue(withIdentifier: "unwindToMainSegue", sender: self)
    }
    private func indexRand (_ rand: UInt32) -> Int
    {
        for i in stride(from: 0, to: randARR.count, by: 1)
        {
            if randARR[i] == rand //if rand exists, it means an image with the name "rand" was already picked at least once
            {
                return i
            }
        }
        return -1
    }
    
    @objc private func decrementGlobalTimer()
    {
        globalSeconds -= 1
        if chosengame == 10
        {
            if(globalSeconds == 0)
            {
                globalTimer.invalidate()
                for i in stride(from: 0, to: btnARR.count, by: 1)
                {
                    btnARR[i].isHidden = true
                }
            }
        }
        globalTimeL.text = "\(globalSeconds)"
        if(globalSeconds == 0)
        {
            gameEndAlertAndTimeInvalidate()
            ballonAppearsTimer.invalidate()
        }
    }
    @objc private func startScoreTimer()
    {
        timeElapsed += 1
    }
    private func addScoreAndTimeToGame()
    {
        globalTimeL = UILabel(frame: CGRect(x: 15, y: 70, width: 128, height: 40))
        globalTimeL.text = "\(globalSeconds)"
        globalTimeL.backgroundColor = UIColor.orange
        globalTimeL.alpha = 0.9
        globalTimeL.font = UIFont(name: "Apple Color Emoji", size: 40.0)
        BGImageView.addSubview(globalTimeL)
        
        let image = UIImage(named: "score")
        globalScoreIMG = UIImageView(image: image)
        globalScoreIMG.frame = CGRect(x: 820, y: 70, width: 120, height: 40)
        globalScoreIMG.contentMode = .scaleToFill
        BGImageView.addSubview(globalScoreIMG)
        
        globalScoreL = UILabel(frame: CGRect(x: 945, y: 70, width: 125, height: 40))
        globalScoreL.text = "\(globalScore)"
        globalScoreL.font = UIFont(name: "Apple Color Emoji", size: 30.0)
        
        BGImageView.addSubview(globalScoreL)
    }
    
    private func playCheer()
    {
        let audioPath = Bundle.main.path(forResource: "Crowd-cheering-sound-effect", ofType: "mp3")
        
        let url = URL(fileURLWithPath: (audioPath)!)
        
        do {
            player = try AVAudioPlayer(contentsOf: url)
            player?.play()
        }
        catch {
            print("error mp3")
        }
        
    }
    private func playDropObject()
    {
        let audioPath = Bundle.main.path(forResource: "Clicking-sound-effect", ofType: "mp3")
        
         let url = URL(fileURLWithPath: (audioPath)!)
        
        do {
            player = try AVAudioPlayer(contentsOf: url)
            player?.play()
        }
        catch {
            print("error mp3")
        }
        
    }
}

//https://www.youtube.com/watch?v=Xp9uSPflTi4

